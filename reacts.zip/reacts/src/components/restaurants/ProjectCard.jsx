import React from "react";
import { Link } from "react-router-dom";

const FormatDescription = (description) => {
  return description.substring(0, 50) + "...";
};
const ProjectCard = (props) => {
  const { project } = props;

  return (
    <div className="card">
      <img
        src={
          "https://restaurant-api.dicoding.dev/images/small/" +
          project.pictureId
        }
        alt={project.name}
        className="custom-picture"
      />
      <section className="section dark">
        <h5 className="strong">
          <strong>{project.name}</strong>
        </h5>
        <Link to={"/restaurants/" + project.id}>
          <p>{FormatDescription(project.description)}</p>
        </Link>
        <p>City : {project.city}</p>
        <p>Rating : {project.rating}</p>

        <a
          href={"https://www.google.com/maps/place/" + project.city}
          target="_blank"
          rel="noreferrer"
        >
          <button className="bordered">
            <span className="icon-location"></span>
            Cek Lokasi
          </button>
        </a>
      </section>
    </div>
  );
};

export default ProjectCard;
