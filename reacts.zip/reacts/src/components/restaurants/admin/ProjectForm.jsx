import React, { useState } from "react";
import Project from "./Project";

const ProjectForm = ({ project: initialProject, onSave, onCancelEdit }) => {
  const [project, setProject] = useState(initialProject);
  const [errors, setErrors] = useState({
    name: "",
    description: "",
    city: "",
    rating: "",
  });

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!isValid()) return;
    onSave(project);
  };

  const handleChange = (event) => {
    const { type, name, value } = event.target;

    let updatedValue = value;

    if (type === "number") {
      updatedValue = Number(updatedValue);
    }

    const change = {
      [name]: updatedValue,
    };

    let updatedProject;

    setProject((p) => {
      updatedProject = new Project({ ...p, ...change });
      return updatedProject;
    });
    setErrors(() => validate(updatedProject));
  };

  const validate = (project) => {
    let errors = { name: "", description: "", city: "", rating: "" };

    if (project.name.length === 0) {
      errors.name = "Name is required";
    }
    if (project.name.length > 0 && project.name.length < 3) {
      errors.name = "Name need to be more than 3 character";
    }
    if (project.description.length === 0) {
      errors.name = "Description is required";
    }
    if (project.city.length === 0) {
      errors.name = "City is required";
    }
    if (project.rating.length === 0) {
      errors.name = "Rating must be more than Rp 0";
    }

    return errors;
  };

  const isValid = () => {
    return (
      errors.name.length === 0 &&
      errors.description.length === 0 &&
      errors.city.length === 0 &&
      errors.rating.length === 0
    );
  };

  return (
    <form className="input-group vertical" onSubmit={handleSubmit}>
      <label htmlFor="name"> Project Name </label>
      <input
        type="text"
        name="name"
        placeholder="Enter Name"
        value={project.name}
        onChange={handleChange}
      />
      <label htmlFor="description"> Project Description </label>
      <textarea
        name="description"
        placeholder="Enter Description"
        cols="30"
        rows="10"
        value={project.description}
        onChange={handleChange}
      ></textarea>
      <label htmlFor="city"> Project City </label>
      <input
        type="text"
        name="city"
        placeholder="Enter City"
        value={project.city}
        onChange={handleChange}
      />
      <label htmlFor="rating"> Project Rating </label>
      <input
        type="number"
        name="rating"
        placeholder="Enter Rating"
        value={project.rating}
        onChange={handleChange}
      />
      <div className="input-group">
        <button className="primary bordered medium">Save</button>
        <span />
        <button
          type="button"
          className="danger bordered medium"
          onClick={onCancelEdit}
        >
          Cancel
        </button>
      </div>
    </form>
  );
};

export default ProjectForm;
