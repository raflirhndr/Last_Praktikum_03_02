export default class Project {
  id = "";
  name = "";
  description = "";
  pictureId = "";
  city = "";
  rating = "";

  constructor(initilizer) {
    this.id = initilizer.id;
    this.name = initilizer.name;
    this.description = initilizer.description;
    this.pictureId = initilizer.pictureId;
    this.city = initilizer.city;
    this.rating = initilizer.rating;
  }
}
