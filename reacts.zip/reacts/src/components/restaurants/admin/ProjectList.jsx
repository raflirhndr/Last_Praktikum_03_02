import React, { useState } from "react";
import ProjectCard from "./ProjectCard";
import ProjectForm from "./ProjectForm";

const ProjectList = ({ projects, onSave, setProjects }) => {
  const [projectBeingEdited, setProjectBeingEdited] = useState(null);
  const [setProjectBeingDeleted] = useState(null);

  const handleEdit = (project) => {
    setProjectBeingEdited(project);
  };

  const cancelEditing = () => {
    setProjectBeingEdited(null);
  };

  const handleDelete = (project) => {
    setProjectBeingDeleted(project);
  };

  return (
    <div className="row">
      {projects.map((project) => (
        <div key={project.id} className="cols-row">
          {project === projectBeingEdited ? (
            <ProjectForm
              onSave={onSave}
              onCancelEdit={cancelEditing}
              project={project}
            />
          ) : (
            <ProjectCard
              project={project}
              onEdit={handleEdit}
              onDelete={handleDelete}
              setProjects={setProjects}
              projects={projects}
            />
          )}
        </div>
      ))}
    </div>
  );
};

export default ProjectList;
