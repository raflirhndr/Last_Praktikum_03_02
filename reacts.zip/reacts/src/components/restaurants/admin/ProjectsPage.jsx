import React, { Fragment, useEffect, useState } from "react";
import ProjectList from "./ProjectList";
import { projectAPI } from "./projectAPI";
import Project from "./Project";

const ProjectsPageRestaurant = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(undefined);
  const [currentPage] = useState(1);

  useEffect(() => {
    const loadProjects = async () => {
      setLoading(true);
      try {
        const data = await projectAPI.get(currentPage);
        if (currentPage === 1) {
          setProjects(data);
        } else {
          setProjects((projects) => [...projects, ...data]);
        }
      } catch (e) {
        if (e instanceof Error) {
          setError(e.message);
        }
      } finally {
        setLoading(false);
      }
    };
    loadProjects();
  }, [currentPage]);

  const saveProject = (project) => {
    projectAPI
      .put(project)
      .then((updatedProject) => {
        let updatedProjects = projects.map((p) => {
          return p.id == project.id ? new Project(updatedProject) : p;
        });
        setProjects(updatedProjects);
      })
      .catch((e) => {
        if (e instanceof Error) {
          setError(e.message);
        }
      });
  };

  return (
    <Fragment>
      <h1>Belum bisa nambahin fitur add pak hehehe</h1>
      <h3>
        isi data lagi{" "}
        <a
          href="https://restaurant-api.dicoding.dev/list"
          target="_blank"
          rel="noreferrer"
        >
          {" "}
          disini{" "}
        </a>{" "}
        pak
      </h3>

      {error && (
        <div className="row">
          <div className="card large error">
            <section>
              <p>
                <span className="icon-alert inverse" />
                {error}
              </p>
            </section>
          </div>
        </div>
      )}
      <ProjectList
        onSave={saveProject}
        projects={projects}
        setProjects={setProjects}
      />
      {loading && (
        <div className="center page">
          <span className="spinner primary"></span>
          <p>Loading...</p>
        </div>
      )}
    </Fragment>
  );
};
export default ProjectsPageRestaurant;
