import React from "react";
import { projectAPI } from "./projectAPI";

const FormatDescription = (description) => {
  return description.substring(0, 50) + "...";
};
const ProjectCard = (props) => {
  const { project, onEdit, setProjects, projects } = props;
  const handleEditClick = (projectBeingEdited) => {
    onEdit(projectBeingEdited);
  };
  const handleDeleteClick = (projectBeingDeleted) => {
    projectAPI.delete(projectBeingDeleted.id);
    console.log(project);
    setProjects(projects.filter((data) => data.id != projectBeingDeleted.id));
  };

  return (
    <div className="card">
      <img
        src={
          "https://restaurant-api.dicoding.dev/images/small/" +
          project.pictureId
        }
        alt={project.name}
        className="custom-picture"
      />
      <section className="section dark">
        <h5 className="strong">
          <strong>{project.name}</strong>
        </h5>
        <p>{FormatDescription(project.description)}</p>
        <p>City : {project.city}</p>
        <p>Rating : {project.rating}</p>
        <button className="bordered" onClick={() => handleEditClick(project)}>
          <span className="icon-edit"></span>
          Edit
        </button>
        <button className="bordered" onClick={() => handleDeleteClick(project)}>
          <span className="icon-alert"></span>
          Delete
        </button>
      </section>
    </div>
  );
};

export default ProjectCard;
