import React, { Fragment, useEffect, useState } from "react";
import ProjectList from "./ProjectList";
import { projectAPI } from "./projectAPI";

const ProjectPageRestaurant = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(undefined);
  const [currentPage] = useState(1);

  useEffect(() => {
    const loadProjects = async () => {
      setLoading(true);
      try {
        const data = await projectAPI.get(currentPage);
        if (currentPage === 1) {
          setProjects(data);
        } else {
          setProjects((projects) => [...projects, ...data]);
        }
      } catch (e) {
        if (e instanceof Error) {
          setError(e.message);
        }
      } finally {
        setLoading(false);
      }
    };
    loadProjects();
  }, [currentPage]);

  return (
    <Fragment>
      <h1>Heres your Restaurants</h1>
      <h4>Tambahkan /admin agar bisa edit dan delete</h4>
      {error && (
        <div className="row">
          <div className="card large error">
            <section>
              <p>
                <span className="icon-alert inverse" />
                {error}
              </p>
            </section>
          </div>
        </div>
      )}
      <ProjectList projects={projects} setProjects={setProjects} />
      {loading && (
        <div className="center page">
          <span className="spinner primary"></span>
          <p>Loading...</p>
        </div>
      )}
    </Fragment>
  );
};
export default ProjectPageRestaurant;
