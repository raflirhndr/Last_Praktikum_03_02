import React from "react";

const ProjectDetail = ({ project }) => {
  return (
    <div className="row">
      <div className="col-sm-6">
        <div className="card large">
          <img
            src={
              "https://restaurant-api.dicoding.dev/images/small/" +
              project.pictureId
            }
            alt={project.name}
          />
          <section className="section dark">
            <h3 className="strong">
              <strong>{project.name}</strong>
            </h3>
            <p>{project.description}</p>
            <p>City : {project.city}</p>
            <p>Rating : {project.rating}</p>
            <a
              href={"https://www.google.com/maps/place/" + project.city}
              target="_blank"
              rel="noreferrer"
            >
              <button className="bordered">
                <span className="icon-location"></span>
                Cek Lokasi
              </button>
            </a>
          </section>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetail;
