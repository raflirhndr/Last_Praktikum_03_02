import React from "react";
import ProjectCard from "./ProjectCard";

const ProjectList = ({ projects, setProjects }) => {
  return (
    <div className="row">
      {projects.map((project) => (
        <div key={project.id} className="cols-row">
          <ProjectCard
            project={project}
            setProjects={setProjects}
            projects={projects}
          />
        </div>
      ))}
    </div>
  );
};

export default ProjectList;
