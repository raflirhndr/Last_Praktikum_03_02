export default class Project {
  id = "";
  name = "";
  description = "";
  image = "";
  recipe = "";

  constructor(initilizer) {
    this.id = initilizer.id;
    this.name = initilizer.name;
    this.description = initilizer.description;
    this.image = initilizer.image;
    this.price = initilizer.price;
  }
}
