import React from "react";
import { Link } from "react-router-dom";

const FormatDescription = (description) => {
  return description.substring(0, 50) + "...";
};
const ProjectCard = (props) => {
  const { project } = props;

  return (
    <div className="card">
      <img src={project.image} alt={project.name} className="custom-picture" />
      <section className="section dark">
        <h5 className="strong">
          <strong>{project.name}</strong>
        </h5>
        <Link to={"/makanan/" + project.id}>
          <p>{FormatDescription(project.description)}</p>
        </Link>
        <p>Price : {project.price}</p>
        <button className="bordered">
          <span className="icon-cart"></span>
          Buy
        </button>
      </section>
    </div>
  );
};

export default ProjectCard;
