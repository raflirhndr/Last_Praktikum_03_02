import React from "react";

const ProjectDetail = ({ project }) => {
  return (
    <div className="row">
      <div className="col-sm-6">
        <div className="card large">
          <img src={project.image} alt={project.name} />
          <section className="section dark">
            <h3 className="strong">
              <strong>{project.name}</strong>
            </h3>
            <p>{project.description}</p>
            <p>Price : {project.price}</p>
            <button className="bordered">
              <span className="icon-cart"></span>
              Buy
            </button>
          </section>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetail;
