import React from "react";
import "./App.css";

import ProjectPageMakanan from "./components/makanan/ProjectsPage";
import ProjectPagesMakanan from "./components/makanan/ProjectPage";
import ProjectsPageMakanan from "./components/makanan/admin/ProjectsPage";

import ProjectsPageRestaurant from "./components/restaurants/admin/ProjectsPage";
import ProjectPageRestaurant from "./components/restaurants/ProjectPage";
import ProjectPagesRestaurant from "./components/restaurants/ProjectsPage";

import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom";
import HomePage from "./home/HomePage";

function App() {
  return (
    <BrowserRouter>
      <header className="sticky">
        <NavLink to="/" className="button rounded">
          <span className="icon-home"></span>
        </NavLink>
        <NavLink to="/makanan" className="button rounded">
          Foods
        </NavLink>
        <NavLink to="/restaurants" className="button rounded">
          Restaurants
        </NavLink>
        <NavLink
          to="/restaurants/admin"
          className="button rounded hidden"
        ></NavLink>
        <NavLink
          to="/makanan/admin"
          className="button rounded hidden"
        ></NavLink>
      </header>
      <div className="container">
        <Routes>
          <Route path="/" element={<HomePage />} />

          <Route path="/makanan" element={<ProjectPageMakanan />} />
          <Route path="/makanan/:id" element={<ProjectPagesMakanan />} />
          <Route path="/makanan/admin" element={<ProjectsPageMakanan />} />

          <Route path="/restaurants" element={<ProjectPageRestaurant />} />
          <Route path="/restaurants/:id" element={<ProjectPagesRestaurant />} />
          <Route
            path="/restaurants/admin"
            element={<ProjectsPageRestaurant />}
          />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
